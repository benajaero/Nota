# This is the editor
You can do anything with markdown

<strong> strong things </strong>

<em> emphatic things</em>

<span style='color: blue;'>colourful things</span>

> Quotation things

* Dot points things

[Link things](google.com)

Image things
![Images](https://s-media-cache-ak0.pinimg.com/736x/da/8e/fc/da8efc68a9eb13b228eee3609962a1a5.jpg)

