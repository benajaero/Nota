# Nota
A minimalistic note app


Notae folder is for storing notes