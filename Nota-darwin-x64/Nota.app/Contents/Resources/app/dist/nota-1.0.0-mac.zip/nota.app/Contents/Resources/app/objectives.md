I want to 

* Have a folder of .mds
* That I can fs open and add to textarea with date and title
* I want a textarea that I can use with marked 


* I want to have metadata json file that has name date file
* I want sidebar to list metadata file
* Make files
* Opens file
* Closes file           